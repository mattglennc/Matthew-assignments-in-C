//in your .c file musti include #include first.h
//include fnuction and struct definitions
