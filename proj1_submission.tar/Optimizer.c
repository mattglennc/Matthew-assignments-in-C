#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "InstrUtils.h"
#include "Utils.h"

int main()
{
	Instruction *head;

	head = ReadInstructionList(stdin);
	if (!head) {
		WARNING("No instructions\n");
		exit(EXIT_FAILURE);
	}
	/* YOUR CODE GOES HERE */
	Instruction *ptr = LastInstruction(head);
	while (ptr) {
		if(ptr->opcode==WRITE){
			ptr->critical='t';
		}
		if(ptr->critical=='t'){
			Instruction *ptr2 = ptr->prev;
			while(ptr2){
				if(ptr2->opcode==STORE && ptr2->field1==ptr->field1){
					ptr2->critical='t';
				}
				else{
					if(ptr2->field1==ptr->field2 || ptr2->field1==ptr->field3){
						ptr2->critical='t';
					}
				}
				ptr2=ptr2->prev;
			}
		}
		ptr = ptr->prev;
	}

	Instruction *ptrDC = head;
	Instruction *prev = head->prev;
	Instruction *temp;
	while(ptrDC){
		if(ptrDC->critical!='t'){
				temp=ptrDC;
				if(prev==NULL){
					head=head->next;
					free(temp);
				}
				else{
				prev->next=ptrDC->next;
				(ptrDC->next)->prev=prev;
				free(temp);
				ptrDC=prev;
				}
		}
		prev=ptrDC;
		ptrDC=ptrDC->next;
	}

	if (head) {
		PrintInstructionList(stdout, head);
		DestroyInstructionList(head);
	}
	return EXIT_SUCCESS;
}

