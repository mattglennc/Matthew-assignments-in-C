#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

#define EXP_SZ 8
#define FRAC_SZ 23

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

   char buff;

   unsigned int multiplier = 0;

    for(int i=EXP_SZ+FRAC_SZ; 0<=i; i--) { 

     fscanf(fp, "%c", &buff);

     if(buff=='1'){
         multiplier+=1<<(i);
     }

    }

   
    fscanf(fp, "%c", &buff);

    unsigned int multiplicand = 0;

    for(int i=EXP_SZ+FRAC_SZ; 0<=i; i--) { 

     fscanf(fp, "%c", &buff);

     if(buff=='1'){
         multiplicand+=1<<(i);
     }

    }

    float product = *(float *) &multiplier * *(float *) &multiplicand; // you are not allowed to print from this.
    unsigned int ref_bits = *(unsigned int *) &product; // you are not allowed to print from this. But you can use it to validate your solution.


    bool sign;

    if((0b1 & multiplier>>31) == (0b1 & multiplicand>>31)){
        sign=0;
    }
    else{
        sign=1;
    }

    printf("%d_",sign);

    assert (sign == (1&ref_bits>>(EXP_SZ+FRAC_SZ)));

    int exp_multiplier=0;

    int exp_multiplicand=0;

      for ( int digit=30; 23<=digit; digit-- ) {

        bool val1 = 0b1 & multiplier>>digit;

        bool val2 = 0b1 & multiplicand>>digit;

        if(val1){
            exp_multiplier+=1<<(digit-FRAC_SZ);
        }

        if(val2){
            exp_multiplicand+=1<<(digit-FRAC_SZ);
        }
        
    }

     int exp = exp_multiplier+exp_multiplicand;

     if(exp==0){
         exp=1-1023;
     }
     else{
         exp-=127;
     }

   
    float m_multiplier = 0.0;

    float m_multiplicand = 0.0;

     for ( int digit=22; 0<=digit; digit-- ) {

        bool val1 = 0b1 & multiplier>>digit;

        bool val2 = 0b1 & multiplicand>>digit;

        if(val1){
            m_multiplier+= 1/pow(2,(23-digit));

        }

        if(val2){
            m_multiplicand+= 1/pow(2,(23-digit));

        }    
    }

    float m = 0.0;

    if(exp_multiplier != 0){
        m_multiplier++;
    }
    
    if(exp_multiplicand != 0){
        m_multiplicand++;
    }

    
    m += m_multiplier*m_multiplicand;

    if(m>=2.0){
        exp++;
    }

     if(exp != 0){

        while((m>2.0)){
        m=m/2;    
        } 

    }
    else{

         while((m>=1.0)){
             m=m/2;  
         }
         
    }

    if(m<1.0 && exp!=0){
        m=m/pow(2,exp);
    }

    if(exp==0){
        m=m/pow(2,exp+1);
    }


     m= m - (int)m;

     int frac = m*pow(2,FRAC_SZ);

    
    for ( int bit_index=EXP_SZ-1; 0<=bit_index; bit_index-- ) {
        bool trial_bit = 1&exp>>bit_index;
        printf("%d",trial_bit);
        
    }
    printf("_"); 


    for ( int bit_index=FRAC_SZ-1; 0<=bit_index; bit_index-- ) {
        bool trial_bit = 1&frac>>bit_index;
        printf("%d",trial_bit);
        
    }
        
    return(EXIT_SUCCESS);

}
