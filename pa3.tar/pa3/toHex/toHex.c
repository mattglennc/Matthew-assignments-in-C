#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // first, read the number
    signed short int input;
    fscanf(fp, "%hd", &input); // note how the 'h' modifier shortens the %d to half size

    int sum = 0;

   
    // print bits; you will see this kind of for loop often in this assignment
    for ( int digit=16; 0<=digit; digit-- ) {

        if(digit==16) {continue;}

        bool char_val = 0b1 & input>>digit; 
        

        if(char_val==1){

            sum+=(1<<(digit%4));

        }

        if(digit%4==0){

             switch(sum) {
                     case 10 :
                        printf("A");
                        break;

                     case 11 :
                     printf("B");
                        break;

                     case 12 :
                        printf("C" );
                        break;

                     case 13 :
                        printf("D" );
                        break;

                     case 14 :
                        printf("E" );
                        break;

                     case 15 :
                        printf("F" );
                        break;

                     default :
                        printf("%d",sum );

                           }
            sum=0;
        }
    }
    printf("\n");


    return EXIT_SUCCESS;

}
