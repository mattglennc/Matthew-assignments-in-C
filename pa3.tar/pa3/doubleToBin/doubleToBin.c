#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

#define EXP_SZ 11
#define FRAC_SZ 52

int main(int argc, char *argv[]) {

 

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return 0;
    }

    // first, read the number
    double value;
    fscanf(fp, "%lf", &value);

    unsigned long int ref_bits = *(unsigned long int*) &value;

    bool sign = value<0.0;
    printf("%d_",sign);
    assert (sign == (1&ref_bits>>(EXP_SZ+FRAC_SZ))); // validate your result against the reference

    
    double fraction = sign ? -value : value;

    signed short trial_exp=(1<<(EXP_SZ-1))-1; 

    while(!(1.0 <= fraction/pow(2,trial_exp) && fraction/pow(2,trial_exp) < 2.0)){

        if(trial_exp==-1023){
            break;
        }

        trial_exp--;
    }

    
    unsigned short bias = (1<<(EXP_SZ-1))-1;

    signed short exp = trial_exp + bias;

    
    for (int exp_index=EXP_SZ-1; 0<=exp_index; exp_index--) {

        bool exp_bit = 1&exp>>exp_index;

        printf("%d",exp_bit);

        assert (exp_bit == (1&ref_bits>>(exp_index+FRAC_SZ))); 
    }

    printf("_");
    
    if(exp != 0){

        while((fraction>2.0)){
            fraction=fraction/2;    
        } 

    }
    else{
         while((fraction>=1.0)){
             fraction=fraction/2;  
         }

    }

    if(fraction<1.0 && exp!=0){
        fraction=fraction/pow(2,trial_exp);

    }

    if(exp==0){
        fraction=fraction/pow(2,trial_exp+1);

    }

   
    fraction=fraction-(int)fraction;

    bool frac_array[FRAC_SZ+1]; 

    for (int frac_index=FRAC_SZ; 0<=frac_index; frac_index--) {

        frac_array[frac_index] = false; 

        fraction=fraction*2;

        if(fraction>=1){
            frac_array[frac_index]=1;
            fraction--;

        }
        
    }

  
    bool carry = frac_array[FRAC_SZ];

        for (int i=0; i<FRAC_SZ+1; i++) { 

        if(carry){

            if(frac_array[i]==1){
                frac_array[i]=0;
            }
            else{
                frac_array[i]=1;
                carry=false;
            }
        }
       
    } 

    

    for ( int frac_index=FRAC_SZ-1; 0<=frac_index; frac_index-- ) {
        bool frac_bit = frac_array[frac_index+1]; // skipping the extra LSB bit for rounding
        printf("%d", frac_bit);
         //assert (frac_bit == (1&ref_bits>>frac_index)); // validate your result against the reference
    }

}
