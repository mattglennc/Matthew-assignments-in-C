#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // first, read the minuend (number to be subtracted from)
    char buff;
    bool minuend[8]; // suggested that you store bits as array of bools; minuend[0] is the LSB
    for (int i=7; 0<=i; i--) { // read MSB first as that is what comes first in the file
    
        fscanf(fp, "%c", &buff);

        if(buff=='1'){
            minuend[i]=1;
        }
        else{
            minuend[i]=0;
        }
        
    }

    // notice that you are reading two different lines; caution with reading
    /* ... */

    fscanf(fp, "%c", &buff);

    // second, read the subtrahend (number to subtract)
    bool subtrahend[8]; // suggested that you store bits as array of bools; subtrahend[0] is the LSB
    for (int i=7; 0<=i; i--) { // read MSB first as that is what comes first in the file
         
        fscanf(fp, "%c", &buff);

        if(buff=='1'){
            subtrahend[i]=1;
        }
        else{
            subtrahend[i]=0;
        }
      
    } 

    for(int i = 0; i<8; i++){

        if(subtrahend[i]==1){

            subtrahend[i]=0;

        }
        else{
            subtrahend[i]=1;
        }
     
    }
 

    bool carry = true; 

    for (int i=0; i<8; i++) {

        if(carry){

            if(subtrahend[i]==1){
                subtrahend[i]=0;

            }
            else{
                subtrahend[i]=1;
                carry=false;

            }
        }
       
    }

   
    
    bool difference[8];

    carry = false;
    for(int i = 0; i<8; i++){

        int temp = minuend[i]+subtrahend[i];

        if(carry){
            temp++;
        }
     
        if(temp>1){
            difference[i]=temp-2;
            carry=true;

        }
        else{
            difference[i]=temp;
            carry=false;
            
        }

        temp=0;
    }

    // print the difference bit string
    for (int i=7; 0<=i; i--)
        printf("%d",difference[i]); 

    return EXIT_SUCCESS;

}
