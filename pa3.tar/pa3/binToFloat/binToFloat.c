#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define EXP_SZ 8
#define FRAC_SZ 23

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    
   char buff;

   unsigned int binary = 0;

    for(int i=EXP_SZ+FRAC_SZ; 0<=i; i--) { 

     fscanf(fp, "%c", &buff);

     if(buff=='1'){
         binary+=1<<(i);
         
        }

    }

    bool sign = 0b1 & binary>>31;

    int e =0;
 
    for (int digit=30; 23<=digit; digit--) {

        bool val = 0b1 & binary>>digit;

        if(val){
            e+=1<<(digit-FRAC_SZ);
        }       
    }
    
     if(e==0){
         e=1-1023;
     }
     else{
         e-=127;
     }
   

    float m = 0;

     for (int digit=22; 0<=digit; digit--) {

        bool val = 0b1 & binary>>digit;

        if(val){
            m+= 1/pow(2,(23-digit));
        }
      
    }

    if(e!=(1-1023)){
        m++;
        
    }
    

    // https://www.tutorialspoint.com/c_standard_library/c_function_ldexp.htm
    double number = ldexp ( m, e );
    number = sign ? -number : number;
    printf("%e\n", number);

    return EXIT_SUCCESS;

}
